<?php


function add_styles_to_theme()
{

	wp_enqueue_style('phe_res7', get_template_directory_uri() . '/assets/css/style.css', array(), '1.0.0', 'all');
	wp_enqueue_style('name_for_this_style7', get_template_directory_uri() . '/assets/css/style-res.css', array(), '1.0.0', 'all');


	/*Scripts*/
	wp_enqueue_script('script', get_template_directory_uri() . '/assets/js/jquery-2.2.2.min.js', array(), '1.0', true);
	wp_enqueue_script('phe_jquery4', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '1.0', true);

	wp_enqueue_script('phe_jquery2', get_template_directory_uri() . '/assets/js/aos.js', array(), '1.0', true);

	wp_enqueue_script('phe_jquery1', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '1.0', true);
	wp_enqueue_script('phe_jquery3', get_template_directory_uri() . '/assets/js/script.js', array(), '1.0', true);
}

add_action('wp_enqueue_scripts', 'add_styles_to_theme');


