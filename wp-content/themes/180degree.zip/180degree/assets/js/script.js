/*global $,AOS,alert*/
$(document).ready(function () {
    "use strict";
    $(window).load(function () {
        $("body").css('overflow-y', 'auto');
        $('#loading').fadeOut(1000);
    });

    $('[data-tool="tooltip"]').tooltip({
        trigger: 'hover',
        animate: true,
        delay: 50,
        container: 'body'
    });
    
    $(window).scroll(function () {
        if ($(this).scrollTop() > 500) {
            $(".toTop").css("bottom", "50px");
        } else {
            $(".toTop").css("bottom", "-200px");
        }
    });

    $(".toTop").click(function () {
        $("html,body").animate({
            scrollTop: 0
        }, 500);
        return false;
    });

    //customize the header
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.main-head').addClass('sticky');
        } else {
            $('.main-head').removeClass('sticky');
        }
    });

    $('[data-fancybox]').fancybox();

    $(".hero-slider").owlCarousel({
        nav: false,
        loop: true,
        dots: true,
        autoplay: false,
        center: true,
        autoplaySpeed: 1000,
        autoplayHoverPause: true,
        items: 1,
        navText: ["<i class='la la-angle-left'></i>", "<i class='la la-angle-right'></i>"],
        animateIn: 'fadeIn',
        animateOut: 'fadeOut'
    });
    
    $(".c-slider").owlCarousel({
        nav: true,
        loop: true,
        dots: false,
        autoplay: false,
        center: true,
        autoplaySpeed: 1000,
        autoplayHoverPause: true,
        items: 1,
        navText: ["<i class='la la-angle-left'></i>", "<i class='la la-angle-right'></i>"],
        animateIn: 'fadeIn',
        animateOut: 'fadeOut'
    });
    
    $(".testo-slider").owlCarousel({
        nav: true,
        loop: true,
        dots: false,
        autoplay: false,
        center: true,
        autoplaySpeed: 1000,
        autoplayHoverPause: true,
        items: 1,
        navText: ["<i class='la la-angle-left'></i>", "<i class='la la-angle-right'></i>"],
        animateIn: 'fadeIn',
        animateOut: 'fadeOut'
    });

    $(".pr-slider").owlCarousel({
        nav: true,
        loop: true,
        navText: ["<i class='la la-angle-left'></i>", "<i class='la la-angle-right'></i>"],
        dots: false,
        autoplay: false,
        items: 4,
        autoplayHoverPause: true,
        center: false,
        responsiveClass: true,
        rtl: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 4
            },
            1300: {
                items: 4
            }
        }
    });

    AOS.init({
        once: true
    });

    $('.op-menu').click(function () {
        $('.overlay-menu').toggleClass('active');
        $(this).toggleClass('clicked');
        $('html').toggleClass('off');
    });

    if ($('.nice-select').length) {
        $('.nice-select').niceSelect();
    }
    
    $('.hero-s').height(window.innerHeight);

});
